//: A UIKit based Playground for presenting user interface

import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        kadanesAlgorithm(arrProb: [-2, 1, -3, 4, -1, 2, 1, -5, 4])
    }
    
    func kadanesAlgorithm(arrProb: Array<Int>){
        if arrProb.isEmpty { return }
        var arrMaximumGroup: Array<Int> = []
        var arrGroup: Array<Int> = [arrProb.first!]
        var maximumValue: Int = arrProb.first!
        var currentMaximum: Int = maximumValue
        
        for i in 1 ..< arrProb.count{
            let newGroup = [arrProb[i]]
            var checkGroup = arrGroup
            checkGroup.append(arrProb[i])
            
            currentMaximum = checkGroup.reduce(0,+)
            if currentMaximum > arrProb[i]{
                arrGroup = checkGroup
            }
            else{
                arrGroup = newGroup
            }
            
            if maximumValue < currentMaximum{
                maximumValue = currentMaximum
                arrMaximumGroup = arrGroup
            }
        }
        print(arrMaximumGroup)
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
