//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        starPyramid(rows: 5)
        pascalsTriangle(rows: 10)
    }
    
    func starPyramid(rows: Int) {
        var k = 1
        var starPattern: String = ""
        for i in stride(from: rows, through: 0, by: -1) {
            for _ in 0 ..< i{
                starPattern.append(" ")
            }
            for _ in 0 ..< k{
                starPattern.append("*")
            }
            print(starPattern)
            starPattern = ""
            k = k+2
        }
    }

    func pascalsTriangle(rows: Int) {
        var prevArr: [Int] = [1,1]
        var currentArr: [Int] = []
        
        var strPrint: String = ""
        for i in 1 ... rows{
            strPrint = ""
            for j in 0 ..< i{
                if j == 0 || j == (i-1){
                    currentArr.append(1)
                    strPrint.append("1")
                }
                else{
                    let result = prevArr[j-1] + prevArr[j]
                    currentArr.append(result)
                    strPrint.append(result.description)
                }
            }
            prevArr = currentArr
            currentArr.removeAll()
            print(strPrint)
        }
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
