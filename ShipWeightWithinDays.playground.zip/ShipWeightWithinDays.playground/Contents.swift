//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        print(shipWithinDays([1,2,3,4,5,6,7,8,9,10], 5))
    }
    
    func shipWithinDays(_ weights: [Int], _ days: Int) -> Int {
            var low: Int = 0
            var max: Int = 0
            var mid: Int = 0
            var result: Int = 0
            for value in weights{
                max += value
                if value > low{
                    low = value
                }
            }
            
            if days == weights.count{
                return low
            }
            
            while (low <= max){
                mid = (low + max)/2
                if isPossible(weights: weights, days: days, mid: mid){
                    result = mid
                    max = mid - 1
                }
                else{
                    low = mid + 1
                }
            }
            return result
        }
        
        func isPossible(weights: [Int], days: Int, mid: Int) -> Bool{
            var day = 1
            var sum:Int = 0
            for value in weights{
                sum += value
                if sum > mid{
                    day = day + 1
                    sum = value
                }
            }
            return day <= days
        }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
