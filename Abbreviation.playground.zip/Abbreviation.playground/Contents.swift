//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    var result: Bool = false
    override func loadView() {
        abbreviation(a: "AbcDE", b: "ABDE")
    }
    
    func abbreviation(a: String, b: String) -> String {
        findAbberviation(a: a, b: b)
        return result ? "YES" : "NO"
    }
    
    func findAbberviation(a: String, b: String){
        if a == b{
            print("Same")
            result = true
            return
        }
        if !a.isEmpty{
            var arrA = Array.init(a).map{String($0)}
            if String(a.first!).compare(String(a.first!).capitalized) != .orderedSame{
                //Small letter
                arrA[0] = String(a.first!).capitalized
                findAbberviation(a: arrA.joined(), b: b)
                arrA.remove(at: 0)
                findAbberviation(a: arrA.joined(), b: b)
            }
            else{
                let index = arrA.firstIndex { (str) -> Bool in
                    return str.compare(str.capitalized) != .orderedSame
                }
                
                if index == nil{
                    print("Not Same")
                    return
                }
                else{
                    arrA[index!] = arrA[index!].capitalized
                    findAbberviation(a: arrA.joined(), b: b)
                    arrA.remove(at: index!)
                    findAbberviation(a: arrA.joined(), b: b)
                }
            }
        }
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
