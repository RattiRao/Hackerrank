//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        StringPermutation(str: "ABCD")
    }
    
    func StringPermutation(str: String) {
        /*
         Append first character fix and replace with first characters
         */
        print(str)
        StringPermutationStart(strFixed: "", arrStringCalc: Array(str))
    }
    
    func StringPermutationStart(strFixed: String, arrStringCalc: [Character])  {
        if arrStringCalc.isEmpty{
            return
        }
        var updatedArrString = arrStringCalc
        
        if strFixed != ""{
        
            updatedArrString.remove(at: 0)
        }
        for i in 0 ..< updatedArrString.count{
            var arrTemp = updatedArrString
            
            let temp = arrTemp[0]
            arrTemp[0] = arrTemp[i]
            arrTemp[i] = temp
            
            print(strFixed + arrTemp.map{String($0)}.joined())
            let strFixedUpdated = strFixed + String(arrTemp.first!)

            StringPermutationStart(strFixed: strFixedUpdated, arrStringCalc: arrTemp)
        }
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
