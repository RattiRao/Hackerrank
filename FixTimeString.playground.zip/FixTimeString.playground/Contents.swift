//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        print(self.fixTimeString(time: "24:70:200"))
    }
    
    func fixTimeString(time: String) -> String{
        var arrTime = (time as NSString).components(separatedBy: ":")
        arrTime.reverse()
        var arrResult: [String] = []
        var updateMinSec: Int = 0
        for (i,str) in arrTime.enumerated(){
            let value = (Int(str) ?? 0) + updateMinSec
            if i != 2{//Not a hour
                if value > 60{
                    let diff = value/60
                    arrResult.append((value - (60*diff)).description)
                    updateMinSec = diff
                }
                else{
                    arrResult.append(value.description)
                }
            }
            else{
                //Handle hours
                if value > 24{
                    let diff = value/24
                    let hour = (value - (24*diff))
                    arrResult.append((hour - 1).description)
                    continue
                }
                else if value == 24{
                    if (Int(arrTime[0]) ?? 0) > 0 || (Int(arrTime[1]) ?? 0) > 0{
                        arrResult.append("0")
                        continue
                    }
                }
                arrResult.append(value.description)
            }
        }
        arrResult.reverse()
        return arrResult.joined(separator: ":")
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
