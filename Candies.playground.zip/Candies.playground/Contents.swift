//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        candies(n: 3, arr: [4,6,4,5,6,2])
    }
    
    func candies(n: Int, arr: [Int]) -> Int {
        // Write your code here
        if arr.isEmpty{
            return 0
        }
        var candy:Int = 1
        var arrCandy:[Int] = [1]
        var currentVal: Int = arr.first!
        for (i,value) in arr.enumerated(){
            if i == 0{
                continue
            }
            if value > currentVal{
                candy = candy + 1
                arrCandy.append(candy)
            }
            else if value == currentVal{
                if candy == 1{
                    candy = 2
                }
                else {
                    candy = 1
                }
                arrCandy.append(candy)
            }
            else if i == arr.count - 1{
                //Last Index
                candy = 1
                arrCandy.append(candy)
            }
            else if value > arr[i+1]{
                candy = 2
                arrCandy.append(candy)
            }
            else{
                candy = 1
                arrCandy.append(candy)
            }
            currentVal = value
        }
        return arrCandy.reduce(0,+)
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
