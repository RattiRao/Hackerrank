//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    
    var info: [[String]] = [
        ["M", "S", "E", "F"],
        ["R", "A", "T", "D"],
        ["L", "O", "N", "E"],
        ["K", "A", "F", "B"]
    ]
    
    var isWordPossible: Bool = false
    
    override func loadView() {
        self.possibleWordSolution(input: ["START", "NOTE", "STAND", "STONED"])
    }
    
    func possibleWordSolution(input: [String]){
        var arrResult: [String] = []
        for word in input{
            let arrIndexes = getRowColum(for: String(word.first!))
            for indexes in arrIndexes{
                isWordPossible = false
                let row = indexes.first!
                let column = indexes.last!
                checkPossibleWord(value: info[row][column], row: row, column: column, wordCompare: word, wordFound: "")
                if isWordPossible{
                    arrResult.append(word)
                }
            }
        }
        print(arrResult)
    }

    func getRowColum(for strInfo: String) -> [[Int]]{
        var result: [[Int]] = []
        for (row,arr) in info.enumerated(){
            for (column,str) in arr.enumerated(){
                if str == strInfo{
                    result.append([row,column])
                }
            }
        }
        return result
    }
    
    func checkPossibleWord(value: String, row: Int, column: Int, wordCompare: String, wordFound: String){
        var wordUpdate: String = wordFound
        
        if wordCompare == wordFound{
            isWordPossible = true
            return
        }
        if wordCompare.prefix(wordUpdate.count+1) == (wordUpdate + value){
            wordUpdate = wordUpdate + value
            print(wordUpdate)
            print("\n")
            
            if column != 0{//Left
                checkPossibleWord(value: info[row][column-1], row: row, column: column-1, wordCompare: wordCompare, wordFound: wordUpdate)
            }
            
            if row != info.count - 1{//Bottom
                checkPossibleWord(value: info[row+1][column], row: row+1, column: column, wordCompare: wordCompare, wordFound: wordUpdate)
            }
            
            if column != info[row].count - 1{//Right
                checkPossibleWord(value: info[row][column+1], row: row, column: column+1, wordCompare: wordCompare, wordFound: wordUpdate)
            }
            
            if row != 0{//Top
                checkPossibleWord(value: info[row-1][column], row: row-1, column: column, wordCompare: wordCompare, wordFound: wordUpdate)
            }
            
            //TOP LEFT
            if row != 0 && column != 0{
                checkPossibleWord(value: info[row-1][column-1], row: row-1, column: column-1, wordCompare: wordCompare, wordFound: wordUpdate)
            }
            //Top Right
            if row != 0 && column != info[row].count - 1{
                checkPossibleWord(value: info[row-1][column+1], row: row-1, column: column+1, wordCompare: wordCompare, wordFound: wordUpdate)
            }
            //Bottom Left
            if row != info.count - 1 && column != 0{
                checkPossibleWord(value: info[row+1][column-1], row: row+1, column: column-1, wordCompare: wordCompare, wordFound: wordUpdate)
            }
            //Bottom Right
            if row != info.count - 1 && column != info[row].count - 1{
                checkPossibleWord(value: info[row+1][column+1], row: row+1, column: column+1, wordCompare: wordCompare, wordFound: wordUpdate)
            }
        }
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
