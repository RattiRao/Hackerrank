//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        findElementsMax(arr: [1,3,2,6,4,5], sum: 5)
    }
    
    func findElementsMax(arr: [Int], sum: Int){
        self.getElementMax(arrGroup: [], arrInfo: arr, sum: sum)
    }
    
    func getElementMax(arrGroup: [Int], arrInfo: [Int], sum: Int) {
        
        if arrInfo.isEmpty{
            return
        }
        let currentSum = arrGroup.reduce(0,+)
        var arrTemp = arrInfo
        for value in arrInfo{
            let newGroup = arrGroup + [value]
            arrTemp.removeFirst()
            if currentSum + value == sum{
                print("Match Found: \(newGroup)")
                continue
            }
            else if currentSum + value > sum{
                continue
            }
            else{
                getElementMax(arrGroup: newGroup, arrInfo: arrTemp, sum: sum)
            }
        }
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
